# -*- coding: utf-8 -*-
import scrapy


class __ProjectNamecapitalize__MasterItem(scrapy.Item):
    url = scrapy.Field()
