DB_CONFIG = {
    'dbtype': 'mysql+pymysql',
    'host': '172.16.119.5',
    'dbname': 'duocaiyunspdier',
    'username': 'root',
    'password': 'root',
    'port': '3306',
    'charset': 'utf8mb4'
}
